
\connect template1
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout = '60s';
SET LOCAL lock_timeout = '5s';
SET LOCAL row_security = off;
SELECT json_build_object(
 'database', current_database(),
 'superuser', (SELECT rolsuper FROM pg_catalog.pg_roles WHERE rolname=current_user),
 'row_security_off', current_setting('row_security') = 'off',
 'active_sessions', (SELECT count(*) FROM pg_catalog.pg_stat_activity
   WHERE datid=(SELECT oid FROM pg_catalog.pg_database WHERE datname=current_database())
    AND pid<>pg_backend_pid() AND backend_type='client backend'),
 'large_objects', EXISTS(SELECT FROM pg_catalog.pg_largeobject_metadata),
 'prepared_transactions', EXISTS(SELECT FROM pg_catalog.pg_prepared_xacts
   WHERE database=current_database()),
 'extensions', coalesce((SELECT json_agg(extname ORDER BY extname)
   FROM pg_catalog.pg_extension), '[]'),
 'schemas', coalesce((SELECT json_agg(n.nspname ORDER BY n.nspname)
   FROM pg_catalog.pg_namespace n
   WHERE n.nspname NOT IN ('pg_catalog','information_schema')
    AND n.nspname <> 'pg_toast'
    AND NOT pg_catalog.pg_is_other_temp_schema(n.oid)), '[]'),
 'relations', (SELECT count(*) FROM pg_catalog.pg_class c
   JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname NOT IN ('pg_catalog','information_schema')
    AND n.nspname <> 'pg_toast'
    AND NOT pg_catalog.pg_is_other_temp_schema(n.oid)),
 'routines', (SELECT count(*) FROM pg_catalog.pg_proc p
   JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
   WHERE n.nspname NOT IN ('pg_catalog','information_schema')
    AND n.nspname <> 'pg_toast'
    AND NOT pg_catalog.pg_is_other_temp_schema(n.oid)),
 'types', (SELECT count(*) FROM pg_catalog.pg_type t
   JOIN pg_catalog.pg_namespace n ON n.oid=t.typnamespace
   WHERE n.nspname NOT IN ('pg_catalog','information_schema')
    AND n.nspname <> 'pg_toast'
    AND NOT pg_catalog.pg_is_other_temp_schema(n.oid)),
 'default_privileges', (SELECT count(*) FROM pg_catalog.pg_default_acl)
);
COMMIT;
