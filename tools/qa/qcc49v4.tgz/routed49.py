"""Prepared-only; Root routes exact owned C reads Core -> existing SSH commerce."""
import argparse
import importlib.util
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID

HERE = Path(__file__).parent
REMOTE = '/tmp/qcc49v4/routed49.py'
CORE_DIR = Path('/tmp/qa-c49-commerce-core4')
REMOTE_DIR = Path('/tmp/qa-c49-commerce-read4')
PURPOSE = 'OWN_C_SELECTED_COMMERCE_TWO_STORE_READ'
BASE_SHA = '8cc339a68477e5229460e119e8560c4bd43faaadfcf10fc1e7fe5eb56fff246a'
LIMIT = 2 * 1024**2
PHASE = 'PREFLIGHT'


def load():
    import hashlib
    if hashlib.sha256((HERE / 'root_collect49.py').read_bytes()).hexdigest() != BASE_SHA:
        raise RuntimeError('Frozen base changed')
    spec = importlib.util.spec_from_file_location('routed_base49', HERE / 'root_collect49.py')
    b = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(b)
    return b, b.load_discovery(HERE)


def record(b, directory, phase, argv, payload=None, timeout=15, cwd=None):
    global PHASE
    PHASE = phase
    b.write_private(directory / (phase + '.start.json'), json.dumps({'stage': phase, 'started_unix': time.time()}).encode())
    timed_out = False
    try:
        child = subprocess.run(argv, input=json.dumps(payload).encode() if payload is not None else None,
                               capture_output=True, timeout=timeout, cwd=cwd, check=False)
    except subprocess.TimeoutExpired as exc:
        child = subprocess.CompletedProcess([], None, exc.stdout or b'', exc.stderr or b'')
        timed_out = True
    stdout, stderr = child.stdout or b'', child.stderr or b''
    b.write_private(directory / (phase + '.stdout'), stdout[:LIMIT])
    b.write_private(directory / (phase + '.stderr'), stderr[:LIMIT])
    metadata = dict(stage=phase, returncode=child.returncode, timed_out=timed_out,
                    stdout_sha256=b.sha(stdout[:LIMIT]), stderr_sha256=b.sha(stderr[:LIMIT]),
                    stdout_bytes=len(stdout), stderr_bytes=len(stderr))
    b.write_private(directory / (phase + '.result.json'), json.dumps(metadata).encode())
    b.need(not timed_out and child.returncode == 0, 'readonly_child_failed')
    b.need(len(stdout) <= LIMIT and len(stderr) <= LIMIT, 'oversized_child_output')
    return stdout


def binding(b, d, data):
    original = d.scope_binding(data)
    b.need(data.get('selected_host') == 'commerce' and data.get('api_container_id') == b.API_CID,
           'actual_selected_commerce_required')
    b.need(d.h.hex64(data.get('placement_receipt_sha256')), 'placement_receipt_hash_required')
    return {**original, 'selected_host': 'commerce', 'purpose': PURPOSE,
            'placement_receipt_sha256': data['placement_receipt_sha256'],
            'routed_helper_sha256': d.h.file_sha(Path(__file__))}


def validate(b, d, data):
    expected = binding(b, d, data)
    ack = data['read_ack']
    b.need(ack.get('purpose') == PURPOSE and ack.get('scope_sha256') == d.h.digest(expected)
           and ack.get('helper_sha256') == d.h.file_sha(Path(__file__)), 'unbound_routed_ACK')
    issued = datetime.fromisoformat(ack['issued_at_utc'].replace('Z', '+00:00'))
    b.need(issued.tzinfo is not None and 0 <= (datetime.now(UTC) - issued).total_seconds() <= 300,
           'stale_routed_ACK')
    b.need(ack.get('root_readonly_authorized') is True and ack.get('exclusive_actor') is True
           and ack.get('inprogress') is False and ack.get('model_calls_authorized') is False
           and ack.get('readonly_sql_authorized') is True, 'routed_read_scope_not_authorized')
    drain = ack['global_drain']
    b.need(drain.get('evidence_complete') is True and time.time() - 60 <= drain['observed_unix'] <= time.time() + 5
           and d.h.hex64(drain.get('evidence_sha256')) and set(drain['counts']) == {'generations', 'operations', 'leases', 'restorations'}
           and all(type(v) is int and v == 0 for v in drain['counts'].values()), 'fresh_actual_drain_required')
    ids = data['exact_scoped_identifiers_private']
    b.need(set(ids) == {'owner_id', 'project_id', 'workspace_id'}, 'exact_three_private_ids_required')
    for key, value in ids.items():
        b.need(str(UUID(value)) == value, 'canonical_private_UUID_required')
        b.need(b.sha(value.encode()) == data['fixture'][key + '_sha256'], 'private_UUID_scope_differs')
    b.need(data['fixture']['owner_id_sha256'] == b.FIXTURE['owner_id_sha256'], 'frozen_owner_differs')
    return expected


PLACEMENT_VERIFY = r'''
import os,stat
fd=os.open('/tmp/qa-owned-c-placement-1.json',os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd) as f:
 s=os.fstat(f.fileno()); assert stat.S_ISREG(s.st_mode) and stat.S_IMODE(s.st_mode)==0o600 and s.st_uid==os.geteuid() and s.st_size<=65536
 receipt=json.load(f)
safe=receipt['safe_summary']; placed=receipt['exact_scoped_identifiers_private']
assert safe['status']=='ACTUAL_OWN_C_READONLY_PLACEMENT' and safe['revision']==x['revision']
assert safe['api_container_id']=='49c04e498f7e36294d8a637ab2e6b6457eec27d49155f31461c162b73d1ddb79'
assert safe['selected_host']=='commerce' and safe['registry_single'] is False and safe['registry_resolved_same_name'] is True
assert receipt['placement_private']['orchestrator']=='commerce'
assert placed==ids and safe['scope_id_hashes']==x['hashes']
print(json.dumps({'ids':{k:ids[k] for k in ('owner_id','project_id','workspace_id')},'placement_receipt_sha256':hashlib.sha256(json.dumps(receipt,sort_keys=True,separators=(',',':')).encode()).hexdigest()}))
'''


def core(b, d):
    b.need(os.path.realpath(sys.prefix) == os.path.realpath('/opt/omnia/apps/orchestrator/.venv'), 'normal_host_venv_required')
    b.new_attempt_dir(CORE_DIR)
    api_lookup = d.API_LOOKUP.replace('print(json.dumps(ids))', '') + PLACEMENT_VERIFY
    # Exact approved native lookup plus private, existing placement receipt read.
    placement = json.loads(record(b, CORE_DIR, 'API_PLACEMENT_READ',
        ['docker', 'exec', '-i', b.API_CID, 'python', '-E', '-c', api_lookup],
        {'revision': b.RELEASE, 'hashes': {k: v for k, v in b.FIXTURE.items() if k.endswith('_sha256')}}))
    observed = time.time()
    raw = record(b, CORE_DIR, 'DRAIN_STATUS', ['docker', 'exec', '-i', b.API_CID, 'python', '-E', '-c', b.DRAIN_SCRIPT], timeout=30)
    data = dict(revision=b.RELEASE, fixture=b.FIXTURE.copy(), api_container_id=b.API_CID,
                controller_source_sha=b.RELEASE, selected_host='commerce', **placement)
    data['exact_scoped_identifiers_private'] = data.pop('ids')
    data['read_ack'] = dict(purpose=PURPOSE, scope_sha256=d.h.digest(binding(b, d, data)),
        helper_sha256=d.h.file_sha(Path(__file__)), issued_at_utc=datetime.now(UTC).isoformat(),
        root_readonly_authorized=True, exclusive_actor=True, inprogress=False,
        model_calls_authorized=False, readonly_sql_authorized=True,
        global_drain=dict(evidence_complete=True, observed_unix=observed, evidence_sha256=b.sha(raw), counts=b.validated_counts(raw)))
    validate(b, d, data)
    b.write_private(CORE_DIR / 'routed-read-ack.private.json', json.dumps(data, sort_keys=True).encode())
    remote = ['/opt/omnia/apps/orchestrator/.venv/bin/python', '-E', REMOTE, '--execute-commerce']
    # Existing alias/auth only: no keys, password, service config, remote env or API copied.
    out = record(b, CORE_DIR, 'COMMERCE_READ',
                 ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'commerce', *remote], data, timeout=360)
    return json.loads(out)


SERVING_STATE_EXTENSION = r'''
from yleum_orchestrator.services.cell_state import retained_serving_fencing_epoch
assert metadata.is_file() and 'quiesce_state' in m and m['quiesce_state'] in (None,'complete')
machine_path=root/x['ids']['workspace_id']/'machine.json'
assert machine_path.is_file()
machine=_read_plain_json_file(machine_path)
assert machine.get('workspace_id')==x['ids']['workspace_id']
serving=retained_serving_fencing_epoch(state,machine_epoch=machine.get('epoch'),machine_ready_epoch=machine.get('ready_epoch'))
assert type(serving) is int and 0<serving<=state.fencing_epoch
assert all(type(v) is int and v==serving for v in (machine.get('epoch'),machine.get('ready_epoch'),m.get('epoch')))
result.update(machine_state_present=True,machine_epoch=machine['epoch'],machine_ready_epoch=machine['ready_epoch'],
 machine_metadata_epoch=m['epoch'],serving_fencing_epoch=serving,serving_epoch_resolver='retained_serving_fencing_epoch')
print(json.dumps(result))
'''


def serving_state_script(d):
    # Adapter-only read extension. Frozen approved helper bytes are unchanged.
    return d.STATE_LOOKUP.replace('print(json.dumps(result))', '') + SERVING_STATE_EXTENSION


def validate_serving_state(b, state):
    epoch = state.get('serving_fencing_epoch')
    controller = state.get('fencing_epoch')
    b.need(type(controller) is int and controller > 0 and type(epoch) is int and 0 < epoch <= controller
           and state.get('machine_metadata_present') is True and state.get('machine_state_present') is True
           and all(type(state.get(k)) is int and state[k] == epoch
                   for k in ('machine_epoch', 'machine_ready_epoch', 'machine_metadata_epoch'))
           and state.get('active_generation_run_id') is None and state.get('active_generation_fencing_epoch') is None
           and state.get('profile_version') in {'docker-owner-cell-resources-v1', 'docker-owner-cell-resources-v2'}
           and state.get('restore_in_progress') is False
           and 'quiesce_state' in state and state['quiesce_state'] in (None, 'complete'),
           'controller_serving_binding_unknown_or_active')


def validate_database_serving_fence(b, owned, state, scope):
    if scope == 'project':
        epoch = owned.get('fencing_epoch')
        b.need(type(epoch) is int and epoch == state['serving_fencing_epoch'],
               'project_database_serving_fence_differs')
    else:
        b.need(scope == 'trusted_core' and owned.get('fencing_epoch') is None,
               'trusted_core_has_no_portable_fence')


SERVICE_IDENTITY_SCRIPT = r'''
import json,subprocess
rows=[]
for unit in ('yleum-orchestrator.service','omnia-orchestrator.service'):
 child=subprocess.run(['systemctl','show',unit,'--all','--property=Id','--property=LoadState',
  '--property=ActiveState','--property=WorkingDirectory','--property=MainPID'],capture_output=True,timeout=5,check=False)
 assert len(child.stdout)<=65536 and len(child.stderr)<=65536
 rows.append(dict(requested_unit=unit,returncode=child.returncode,stdout=child.stdout.decode(),stderr=child.stderr.decode()))
print(json.dumps(rows))
'''


def select_service_identity(b, rows):
    units = {'yleum-orchestrator.service', 'omnia-orchestrator.service'}
    b.need(isinstance(rows, list) and len(rows) == 2
           and {row.get('requested_unit') for row in rows} == units, 'fixed_service_names_required')
    active = []
    expected = os.path.realpath('/opt/omnia/apps/orchestrator')
    for row in rows:
        props = {}
        for line in row['stdout'].splitlines():
            if not line:
                continue
            key, value = line.split('=', 1)
            b.need(key not in props, 'duplicate_service_property')
            props[key] = value
        b.need(set(props) == {'Id', 'LoadState', 'ActiveState', 'WorkingDirectory', 'MainPID'}
               and props['Id'] in units and props['MainPID'].isdigit(), 'service_identity_unknown')
        pid = int(props['MainPID'])
        if props['LoadState'] == 'not-found':
            b.need(row['returncode'] in (0, 1) and props['ActiveState'] == 'inactive' and pid == 0,
                   'missing_service_not_proven_inactive')
            continue
        b.need(row['returncode'] == 0 and props['LoadState'] == 'loaded', 'service_query_failed')
        if props['ActiveState'] == 'active':
            b.need(pid > 0 and os.path.realpath(props['WorkingDirectory']) == expected,
                   'active_service_directory_differs')
            active.append(props)
        else:
            b.need(props['ActiveState'] in {'inactive', 'failed'} and pid == 0, 'service_state_unknown')
    b.need(bool(active) and len({int(props['MainPID']) for props in active}) == 1,
           'missing_or_multiple_active_controller_processes')
    return active[0]


def expected_database_destination(scope):
    destinations = {'project': '/var/lib/postgresql/data', 'trusted_core': '/var/lib/postgresql'}
    if scope not in destinations:
        raise RuntimeError('Unknown physical store scope')
    return destinations[scope]


def validate_scoped_mounts(d, actual, scope):
    destination = expected_database_destination(scope)
    mounts = actual['Mounts']
    exact = [item for item in mounts if item.get('Destination') == destination]
    d.h.need(len(exact) == 1 and exact[0].get('Type') == 'volume'
             and isinstance(exact[0].get('Name'), str) and exact[0]['Name'], 'no_exact_scope_data_volume')
    extra_pg = [item for item in mounts if item is not exact[0]
                and (item.get('Destination') == '/var/lib/postgresql'
                     or str(item.get('Destination', '')).startswith('/var/lib/postgresql/'))]
    d.h.need(not extra_pg or (scope == 'trusted_core' and len(extra_pg) == 1
             and extra_pg[0].get('Destination') == '/var/lib/postgresql/data'
             and extra_pg[0].get('Type') == 'tmpfs'), 'conflicting_postgres_mount')
    d.h.need(all(item is exact[0] or item.get('Type') != 'volume'
                or item.get('Name') != exact[0]['Name'] for item in mounts), 'aliased_data_volume_mount')


def verified_mount_clone(function, expected_sha, namespace):
    import hashlib
    import inspect
    source = inspect.getsource(function)
    old = '"/var/lib/postgresql/data"'
    if hashlib.sha256(source.encode()).hexdigest() != expected_sha or source.count(old) != 1:
        raise RuntimeError('Frozen identity function source differs')
    # Change ONLY the expected mount predicate; never alter inspected evidence.
    source = source.replace(old, 'expected_database_destination(scope)')
    namespace = dict(namespace, expected_database_destination=expected_database_destination)
    exec(compile(source, '<verified-scope-mount-clone>', 'exec'), namespace)
    return namespace[function.__name__]


def database_binding_scoped(d, actual, ids, state, scope):
    from types import SimpleNamespace
    validate_scoped_mounts(d, actual, scope)
    identity = verified_mount_clone(d.h.validate_identity,
        '499f8bc7b0252d713dffd507d366521d302174a8760b8798e6a5cdf0e6850be9', d.h.__dict__)
    proof = SimpleNamespace(**{k: v for k, v in d.h.__dict__.items() if not k.startswith('__')})
    proof.validate_identity = identity
    bound = verified_mount_clone(d.database_binding,
        '4de060cf8a2febf9af0dad716ddceb3f46a3ad9f95e2672554d2a0dd1cf2cda6',
        dict(d.__dict__, h=proof))
    return bound(actual, ids, state, scope)


def commerce(b, d, data):
    validate(b, d, data)
    b.need(os.path.realpath(sys.prefix) == os.path.realpath('/opt/omnia/apps/orchestrator/.venv'), 'normal_selected_host_venv_required')
    b.new_attempt_dir(REMOTE_DIR)
    b.write_private(REMOTE_DIR / 'routed-read-ack.private.json', json.dumps(data, sort_keys=True).encode())
    unit = record(b, REMOTE_DIR, 'SERVICE_IDENTITY',
                  ['/opt/omnia/apps/orchestrator/.venv/bin/python', '-E', '-c', SERVICE_IDENTITY_SCRIPT])
    props = select_service_identity(b, json.loads(unit))
    expected = os.path.realpath('/opt/omnia/apps/orchestrator')
    b.need(os.path.realpath(props.get('WorkingDirectory', '')) == expected
           and os.path.realpath('/proc/' + props['MainPID'] + '/cwd') == expected,
           'selected_host_service_directory_differs')
    counter = 0

    def command(argv, *, payload=None, timeout=15, cwd=None):
        nonlocal counter
        validate(b, d, data)
        counter += 1
        b.need(counter <= 18, 'readonly_command_budget_exceeded')
        return record(b, REMOTE_DIR, 'READ_' + str(counter), argv, payload, timeout, cwd)

    d.command = command
    ids = data['exact_scoped_identifiers_private']
    state = d.host_python(serving_state_script(d), {'revision': b.RELEASE, 'ids': ids})
    validate_serving_state(b, state)
    d.h.verified_queries()
    result = dict(status='ACTUAL_OWN_C_COMMERCE_TWO_STORE_DIAGNOSTIC', revision=b.RELEASE,
                  selected_host='commerce', controller_state=state, exact_scoped_identifiers_private=ids,
                  scope_id_hashes={k: v for k, v in b.FIXTURE.items() if k.endswith('_sha256')},
                  databases={}, accepted=False, whole67accepted=[], started_unix=time.time())
    for scope, kind, flag in [('project', 'project-postgres', 'omnia.project_machine'),
                              ('trusted_core', 'postgres', 'omnia.project_cell')]:
        cid = d.find(ids, kind, flag)
        if cid is None:
            result['databases'][scope] = dict(present=False, empty_witness_valid=False,
                                              blocking_reason='missing_exact_owned_container')
            continue
        before = d.inspect(cid)
        owned = database_binding_scoped(d, before, ids, state, scope)
        validate_database_serving_fence(b, owned, state, scope)
        payload = dict(revision=b.RELEASE, ids=ids, state=state, scope=scope, container_id=cid,
                       query_hashes=d.h.QUERY_HASHES)
        witnesses = d.host_python(d.CONTROLLER_SELECT, payload, timeout=150)
        store = dict(present=True, binding=owned, identity=before, catalog=witnesses['catalog-counts.sql'],
                     template1=witnesses['template1-counts.sql'])
        try:
            d.h.need(store['template1'] == d.h.STOCK_TEMPLATE, 'template1_not_stock')
            store['classification'] = d.h.classify_catalog(store['catalog'])
            store['empty_witness_valid'] = True
        except d.h.Blocked as exc:
            store.update(empty_witness_valid=False, blocking_reason=str(exc))
        b.need(d.inspect(cid) == before, 'store_identity_changed_during_read')
        result['databases'][scope] = store
    b.need(d.host_python(serving_state_script(d), {'revision': b.RELEASE, 'ids': ids}) == state,
           'controller_state_changed_during_read')
    present = [v for v in result['databases'].values() if v.get('present') is True]
    for key in ('container_id', 'volume_name'):
        b.need(len({v['binding'][key] for v in present}) == len(present), 'aliased_physical_stores')
    result.update(both_stores_present=len(present) == 2, finished_unix=time.time(),
                  actual_local_collection=True, query_hashes=d.h.QUERY_HASHES, phase='diagnostic')
    d.h.private_output(REMOTE_DIR / 'two-store-diagnostic.private.json', result)
    return dict(status=result['status'], revision=b.RELEASE, selected_host='commerce',
                stores=len(present), both_empty=len(present) == 2 and all(v.get('empty_witness_valid') is True for v in present),
                diagnostic_sha256=d.h.digest(result), actual_execution=True, accepted=False, whole67accepted=[])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-core', action='store_true')
    parser.add_argument('--execute-commerce', action='store_true')
    args = parser.parse_args()
    if not args.execute_core and not args.execute_commerce:
        print(json.dumps({'status': 'NONEXECUTING_PREPARATION', 'actual_execution': False, 'whole67accepted': []}))
        return 0
    try:
        if args.execute_core and args.execute_commerce:
            raise ValueError('Mixed mode')
        b, d = load()
        if args.execute_core:
            result = core(b, d)
        else:
            raw = sys.stdin.read(65537)
            b.need(len(raw) <= 65536, 'input_oversized')
            result = commerce(b, d, json.loads(raw))
        print(json.dumps(result))
        return 0
    except (Exception, KeyboardInterrupt) as exc:
        print(json.dumps({'status': 'COMMERCE_READ_BLOCKED', 'phase': PHASE, 'error_type': type(exc).__name__,
                          'accepted': False, 'whole67accepted': []}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
