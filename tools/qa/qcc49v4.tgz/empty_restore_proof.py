"""Owned C proof preparation. Default does no execution or protected input read.

Only an explicit fresh root ACK permits future --execute-collect on Core.
This helper NEVER restores, bootstraps, migrates, wakes, or calls a model.
"""

import argparse
import hashlib
import json
import os
import re
import subprocess
import time
from pathlib import Path
from uuid import UUID

HERE = Path(__file__).parent
QUERY_HASHES = {
    "catalog-counts.sql": "891196b7e232594438f1c55780974a45f36cd75e312afdf76d3fae9bd68288fd",
    "template1-counts.sql": "9cfc3ce8039cd770ef23f649f1d1642112f4151d922ef346dafd2b9598f62ce2",
}
CONTRACTS = (
    "src/lib/omnia/integration-client.ts",
    "src/lib/omnia/max-config.ts",
    "src/components/MaxAppProvider.tsx",
)
MAX_USER_COLUMNS = [
    ["id", "uuid", True, "gen_random_uuid()"],
    ["max_user_id", "text", True, None],
    ["first_name", "text", True, None],
    ["last_name", "text", False, None],
    ["username", "text", False, None],
    ["language_code", "text", False, None],
    ["photo_url", "text", False, None],
    ["created_at", "timestamp with time zone", True, "now()"],
    ["updated_at", "timestamp with time zone", True, "now()"],
]
STOCK_TEMPLATE = dict(
    database="template1",
    superuser=True,
    row_security_off=True,
    active_sessions=0,
    large_objects=False,
    prepared_transactions=False,
    extensions=["plpgsql"],
    schemas=["public"],
    relations=0,
    routines=0,
    types=0,
    default_privileges=0,
)


class Blocked(RuntimeError):
    pass


def need(value, code):
    if not value:
        raise Blocked(code)


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def hex64(value):
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value) is not None


def read_json(path):
    path = Path(path)
    need(
        path.is_file() and not path.is_symlink() and path.stat().st_size <= 8 * 1024**2,
        "unsafe_input",
    )
    return json.loads(path.read_text())


def verified_queries():
    need(
        all(file_sha(HERE / name) == sha for name, sha in QUERY_HASHES.items()),
        "query_changed",
    )
    return {name: (HERE / name).read_text() for name in QUERY_HASHES}


def validate_fixture(f):
    need(
        f.get("scope") == "owned_C_empty_restore"
        and f.get("fixture_label") == "C"
        and f.get("owner_role") == "user"
        and f.get("ownership_verified") is True
        and f.get("isolated_qa") is True,
        "wrong_fixture",
    )
    for key in (
        "owner_id",
        "project_id",
        "workspace_id",
        "generation_run_id",
        "source_version_id",
        "source_snapshot_id",
        "base_snapshot_id",
    ):
        UUID(f[key])
    need(
        f.get("source_files_sha256")
        and all(hex64(v) for v in f["source_files_sha256"].values()),
        "missing_full_target_source",
    )
    need(
        set(f.get("business_contract_sha256", {})) == set(CONTRACTS)
        and all(hex64(v) for v in f["business_contract_sha256"].values()),
        "missing_sdk_contract",
    )
    need(
        "before" in f["phases"] and set(f["phases"]) <= {"before", "after"},
        "missing_before_phase",
    )
    for phase in f["phases"].values():
        UUID(phase["snapshot_id"])
        need(
            type(phase["fencing_epoch"]) is int and phase["fencing_epoch"] > 0,
            "missing_controller_fence",
        )
        dbs = phase["databases"]
        need(set(dbs) == {"project", "trusted_core"}, "both_databases_required")
        need(
            dbs["project"]["container_id"] != dbs["trusted_core"]["container_id"]
            and dbs["project"]["volume_name"] != dbs["trusted_core"]["volume_name"],
            "aliased_databases",
        )
        for scope, b in dbs.items():
            need(
                hex64(b["container_id"])
                and isinstance(b["volume_name"], str)
                and b["volume_name"]
                and "/" not in b["volume_name"],
                "invalid_database_binding",
            )
            need(
                b["resource_kind"]
                == ("project-postgres" if scope == "project" else "postgres"),
                "invalid_database_kind",
            )
            if scope == "project":
                need(
                    type(b["fencing_epoch"]) is int
                    and b["fencing_epoch"] > 0
                    and b["namespace"],
                    "missing_product_physical_fence",
                )
            else:
                need(
                    b["fencing_epoch"] is None
                    and b.get("namespace") is None
                    and b.get("profile_version")
                    in {
                        "docker-owner-cell-resources-v1",
                        "docker-owner-cell-resources-v2",
                    },
                    "invented_core_physical_fence",
                )
    need(
        f["phases"]["before"]["snapshot_id"] == f["base_snapshot_id"],
        "before_snapshot_mismatch",
    )


def validate_ack(f, ack, revision, phase):
    validate_fixture(f)
    verified_queries()
    need(
        re.fullmatch("[0-9a-f]{40}", revision)
        and ack.get("sha")
        == ack.get("api_revision")
        == ack.get("worker_revision")
        == ack.get("controller_revision")
        == revision,
        "release_mismatch",
    )
    need(
        ack.get("scope") == f["scope"]
        and ack.get("phase") == phase
        and all(ack.get(k) == f[k] for k in ("owner_id", "project_id", "workspace_id")),
        "ack_scope",
    )
    need(
        ack.get("helper_sha256") == file_sha(Path(__file__))
        and ack.get("fixture_sha256") == digest(f)
        and ack.get("query_hashes") == QUERY_HASHES,
        "unbound_ack",
    )
    need(
        all(
            ack.get(k) is True
            for k in (
                "root_authorized",
                "production_delivered",
                "core_quiescence_verified",
                "exclusive_actor",
                "readonly_sql_authorized",
            )
        ),
        "ack_missing_proof",
    )
    need(
        ack.get("inprogress") is False and ack.get("model_calls_authorized") is False,
        "forbidden_scope",
    )
    need(
        time.time() - 300 <= ack.get("approved_unix", 0) <= time.time() + 5, "stale_ack"
    )


def validate_identity(actual, f, phase, scope):
    b = f["phases"][phase]["databases"][scope]
    need(
        actual["Id"] == b["container_id"] and actual["Running"] is True,
        "database_container_mismatch",
    )
    expected = {
        "omnia.managed": "true",
        "omnia.workspace_id": f["workspace_id"],
        "omnia.project_id": f["project_id"],
        "omnia.owner_id": f["owner_id"],
        "omnia.resource_kind": b["resource_kind"],
    }
    if scope == "project":
        expected.update(
            {
                "omnia.project_machine": "true",
                "omnia.namespace": b["namespace"],
                "omnia.fencing_epoch": str(b["fencing_epoch"]),
            }
        )
    else:
        expected.update(
            {
                "omnia.project_cell": "true",
                "omnia.provider": "docker_owner_canary",
                "omnia.profile_version": str(b["profile_version"]),
            }
        )
        need(
            actual["Labels"].get("omnia.fencing_epoch") is None,
            "unexpected_core_epoch_label",
        )
    need(
        all(actual["Labels"].get(k) == v for k, v in expected.items()),
        "database_label_mismatch",
    )
    mounts = [
        m for m in actual["Mounts"] if m["Destination"] == "/var/lib/postgresql/data"
    ]
    need(
        len(mounts) == 1
        and mounts[0].get("Type") == "volume"
        and mounts[0].get("Name") == b["volume_name"],
        "database_volume_mismatch",
    )


def classify_catalog(raw):
    need(
        raw.get("superuser") is True and raw.get("row_security_off") is True,
        "rls_hidden_counts",
    )
    need(
        raw.get("database_layout_valid") is True
        and raw.get("extensions") == ["plpgsql"]
        and all(
            raw.get(k) is False
            for k in (
                "large_objects",
                "prepared_transactions",
                "subscriptions",
                "replication_slots",
            )
        ),
        "incomplete_storage_coverage",
    )
    need(
        isinstance(raw.get("sequences"), list)
        and all(
            s.get("is_called") is False
            and type(s.get("last_value")) is int
            and s["last_value"] == s.get("start_value")
            for s in raw["sequences"]
        ),
        "unclassified_sequence_state",
    )
    rows = raw.get("relations")
    need(isinstance(rows, list) and len(rows) <= 450, "incomplete_catalog")
    seen = set()
    technical = []
    business = 0
    for r in rows:
        key = (r.get("schema"), r.get("name"))
        need(
            all(isinstance(v, str) and v for v in key) and key not in seen,
            "duplicate_or_unknown_relation",
        )
        seen.add(key)
        need(
            r.get("kind") == "table"
            and r.get("partition") is False
            and type(r.get("row_count")) is int
            and r["row_count"] >= 0,
            "unmeasured_relation",
        )
        attested = False
        if key in {
            ("public", "__omnia_migrations"),
            ("public", "__omnia_project_migrations"),
        }:
            project = key[1] == "__omnia_project_migrations"
            a = (
                r.get("project_ledger_attestation" if project else "ledger_attestation")
                or {}
            )
            attested = a.get("shape_attested") is True and hex64(a.get("rows_digest"))
            if project:
                attested = attested and a.get("rows_valid") is True
        elif key == ("public", "max_users"):
            a = r.get("max_users_attestation") or {}
            attested = (
                a.get("owner_is_controller") is True
                and a.get("columns") == MAX_USER_COLUMNS
                and a.get("primary_key") == ["id"]
                and a.get("unique_keys") == [["max_user_id"]]
                and hex64(a.get("rows_digest"))
            )
        if attested:
            technical.append(
                {
                    "identity": key,
                    "row_count": r["row_count"],
                    "rows_digest": a["rows_digest"],
                }
            )
        else:
            need(r["row_count"] == 0, "business_or_unknown_rows_present")
            business += 1
    return {
        "business_row_count": 0,
        "business_relations": business,
        "technical": technical,
        "catalog_sha256": digest(raw),
    }


def validate_context(c, f, phase, revision):
    me, p, g, s = (
        c["api_me"],
        c["api_project"],
        c["api_generation"],
        c["controller_workspace_state"],
    )
    need(
        me["id"] == f["owner_id"]
        and me["role"] == "user"
        and p["id"] == f["project_id"]
        and p["owner_id"] == f["owner_id"]
        and p["current_snapshot_id"] == f["phases"][phase]["snapshot_id"],
        "owner_or_snapshot_changed",
    )
    need(
        c["api_health"]["status"] == "ok"
        and c["api_health"]["release_sha"] == revision
        and c["worker_release_sha"] == c["controller_release_sha"] == revision,
        "context_release_changed",
    )
    need(
        g["id"] == f["generation_run_id"] and g["status"] == "completed",
        "generation_changed",
    )
    need(
        all(s[k] == f[k] for k in ("owner_id", "project_id", "workspace_id"))
        and s["fencing_epoch"] == f["phases"][phase]["fencing_epoch"]
        and s["active_generation_run_id"] is None
        and s["active_generation_fencing_epoch"] is None
        and s["phase"] == "completed"
        and s["bundle_state"] == "resources_ready",
        "workspace_not_quiescent",
    )
    need(
        c["active_activity_ids"] == []
        and c["lifecycle_mutation_active"] is False
        and c.get("evidence_complete") is True,
        "activity_or_lifecycle_unknown",
    )


def inspect_container(container_id):
    # Only whitelisted inspect fields, never Env/secrets or arbitrary Docker IDs.
    fmt = (
        '{"Id":{{json .Id}},"Running":{{json .State.Running}},'
        '"Labels":{{json .Config.Labels}},"Mounts":{{json .Mounts}}}'
    )
    p = subprocess.run(
        ["docker", "inspect", "--format", fmt, container_id],
        capture_output=True,
        timeout=10,
    )
    need(p.returncode == 0 and len(p.stdout) <= 1024**2, "container_inspection_failed")
    return json.loads(p.stdout)


def select_only(container_id, sql):
    # Frozen controller SQL only; local peer auth avoids DSNs/password inspection.
    p = subprocess.run(
        [
            "docker",
            "exec",
            "-i",
            "--user",
            "postgres",
            container_id,
            "timeout",
            "-s",
            "KILL",
            "65",
            "psql",
            "-X",
            "-qAt",
            "-v",
            "ON_ERROR_STOP=1",
            "-v",
            "VERBOSITY=sqlstate",
            "-U",
            "postgres",
            "-d",
            "postgres",
        ],
        input=sql.encode(),
        capture_output=True,
        timeout=70,
    )
    need(
        p.returncode == 0 and len(p.stdout) <= 1024**2, "sql_failed_unknown_never_zero"
    )
    return json.loads(p.stdout)


def collect(args, f):
    ack = read_json(args.ack)
    validate_ack(f, ack, args.revision, args.phase)
    c = read_json(args.context)
    need(ack.get("context_sha256") == digest(c), "unbound_context")
    validate_context(c, f, args.phase, args.revision)
    need(time.time() - 60 <= c["observed_unix"] <= time.time() + 5, "stale_context")
    need(args.output and not Path(args.output).exists(), "output_exists_no_overwrite")
    queries = verified_queries()
    result = {
        "phase": args.phase,
        "scope": f["scope"],
        "revision": args.revision,
        "scope_ids": {k: f[k] for k in ("owner_id", "project_id", "workspace_id")},
        "query_hashes": QUERY_HASHES,
        "started_unix": time.time(),
        "actual_local_collection": True,
        "databases": {},
    }
    for scope, b in f["phases"][args.phase]["databases"].items():
        validate_ack(f, read_json(args.ack), args.revision, args.phase)
        before = inspect_container(b["container_id"])
        validate_identity(before, f, args.phase, scope)
        raw = select_only(b["container_id"], queries["catalog-counts.sql"])
        template = select_only(b["container_id"], queries["template1-counts.sql"])
        need(template == STOCK_TEMPLATE, "template1_not_stock_unknown")
        report = classify_catalog(raw)
        after = inspect_container(b["container_id"])
        validate_identity(after, f, args.phase, scope)
        need(before == after, "database_changed_during_count")
        result["databases"][scope] = {
            "identity": after,
            "catalog": raw,
            "template1": template,
            "classification": report,
        }
    result["finished_unix"] = time.time()
    private_output(Path(args.output), result)
    return {
        "status": "COLLECTED_TWO_OWNED_STORES_EMPTY_NOT_RESTORE_ACCEPTANCE",
        "actual_execution": True,
        "business_row_count": 0,
        "whole67accepted": [],
    }


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def durable_directory(path):
    need(not path.is_symlink(), "unsafe_output_directory")
    if not path.exists():
        durable_directory(path.parent)
        path.mkdir(mode=0o700, exist_ok=True)
    sync_directory(path)
    sync_directory(path.parent)


def private_output(path, value):
    durable_directory(path.parent)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as stream:
        json.dump(value, stream)
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory(path.parent)


def verify_bundle(f, ack, bundle, revision):
    validate_ack(f, ack, revision, "after")
    need(ack.get("bundle_sha256") == digest(bundle), "unbound_bundle")
    op = bundle["api_operation"]
    controller = bundle["controller_operation"]
    for phase in ("before", "after"):
        count = bundle[phase + "_counts"]
        context = bundle[phase + "_context"]
        validate_context(context, f, phase, revision)
        need(
            count["actual_local_collection"] is True
            and count["revision"] == revision
            and count["phase"] == phase
            and count["query_hashes"] == QUERY_HASHES
            and count["scope_ids"]
            == {k: f[k] for k in ("owner_id", "project_id", "workspace_id")}
            and set(count["databases"]) == {"project", "trusted_core"},
            "unproven_global_counts",
        )
        for scope, data in count["databases"].items():
            validate_identity(data["identity"], f, phase, scope)
            need(data["template1"] == STOCK_TEMPLATE, "template1_not_stock")
            classify_catalog(data["catalog"])
    need(
        bundle["before_context"]["observed_unix"]
        <= bundle["before_counts"]["started_unix"]
        <= bundle["before_counts"]["finished_unix"]
        <= bundle["after_counts"]["started_unix"]
        <= bundle["after_counts"]["finished_unix"]
        <= bundle["after_context"]["observed_unix"],
        "unbracketed_observation_window",
    )
    before_core = bundle["before_counts"]["databases"]["trusted_core"]
    after_core = bundle["after_counts"]["databases"]["trusted_core"]
    need(
        before_core["identity"] == after_core["identity"]
        and classify_catalog(before_core["catalog"])["technical"]
        == classify_catalog(after_core["catalog"])["technical"],
        "trusted_identity_metadata_changed",
    )
    need(
        op["project_id"] == f["project_id"]
        and op["source_version_id"] == f["source_version_id"]
        and op["source_snapshot_id"] == f["source_snapshot_id"]
        and op["base_draft_snapshot_id"] == f["base_snapshot_id"]
        and op["target"] == "draft"
        and op["state"] == "completed"
        and op["selected_branch"] == "exact"
        and op["adaptation_run_id"] is None
        and op["execution_policy"] == "automatic_when_safe"
        and op["report"]["mode"] == "exact"
        and op["report"]["database_state"] == "empty"
        and op["report"]["blockers"] == [],
        "operation_not_exact_empty_complete",
    )
    UUID(op["id"])
    candidate = controller.get("candidate_id")
    need(isinstance(candidate, str), "missing_authoritative_candidate")
    try:
        UUID(candidate)
    except ValueError:
        raise Blocked("missing_authoritative_candidate") from None
    need(
        all(controller[k] == f[k] for k in ("owner_id", "project_id", "workspace_id"))
        and controller["operation_id"] == op["id"]
        and controller["state"] == "completed"
        and controller["candidate_id"] == controller["observed"]["candidate_id"]
        and controller["observed"]["applied"] is True
        and controller["observed"]["fencing_epoch"]
        == f["phases"]["after"]["fencing_epoch"],
        "missing_authoritative_controller_journal",
    )
    binding = controller["binding"]
    binding_fields = (
        "serving_route_digest",
        "serving_release_digest",
        "controller_resource_digest",
        "controller_incarnation_digest",
        "controller_generation_digest",
        "provider_digest",
        "source_artifact_digest",
        "database_identity_digest",
        "database_schema_digest",
        "database_role_binding_digest",
        "database_export_digest",
        "source_business_inventory_digest",
        "candidate_business_inventory_digest",
        "source_technical_inventory_digest",
        "candidate_technical_inventory_digest",
        "candidate_artifact_digest",
    )
    need(
        binding.get("version") == 3
        and all(hex64(binding.get(k)) for k in binding_fields),
        "incomplete_controller_binding",
    )
    need(
        controller["binding_digest"] == digest(binding)
        and controller["observed"]["binding_digest"] == controller["binding_digest"],
        "binding_mismatch",
    )
    if binding.get("database_strategy") == "replace_verified_empty":
        need(
            binding.get("version") == 3
            and hex64(binding.get("witness_digest"))
            and hex64(binding.get("target_database_artifact_digest")),
            "missing_empty_replacement_witness",
        )
    else:
        need(
            binding.get("database_strategy") == "preserve_current"
            and binding.get("witness_digest") is None
            and binding.get("target_database_artifact_digest") is None,
            "unknown_database_strategy",
        )
    base, target, applied = (
        bundle["base_snapshot"],
        bundle["target_snapshot"],
        bundle["applied_snapshot"],
    )
    need(
        base["id"] == f["base_snapshot_id"] and base["project_id"] == f["project_id"],
        "pre_restore_source_mismatch",
    )
    need(
        isinstance(applied.get("commit_sha"), str)
        and re.fullmatch("[0-9a-f]{40}", applied["commit_sha"]) is not None,
        "missing_authoritative_source_commit",
    )
    need(
        target["id"] == f["source_snapshot_id"]
        and applied["id"]
        == op["applied_snapshot_id"]
        == f["phases"]["after"]["snapshot_id"]
        and applied["parent_id"] == f["base_snapshot_id"]
        and all(v["project_id"] == f["project_id"] for v in (target, applied))
        and applied["commit_sha"] == controller["observed"]["source_commit_sha"],
        "snapshot_lineage_changed",
    )

    def hashes(files):
        return {p: hashlib.sha256(v.encode()).hexdigest() for p, v in files.items()}

    need(
        hashes(target["files"]) == f["source_files_sha256"] == hashes(applied["files"]),
        "restored_source_changed",
    )
    need(
        {p: hashes(base["files"])[p] for p in CONTRACTS}
        == {p: hashes(applied["files"])[p] for p in CONTRACTS}
        == f["business_contract_sha256"],
        "sdk_changed",
    )
    trace = bundle["normal_ui_trace"]
    need(
        trace["prepare_requests"] == 1
        and trace["operation_ids"] == [op["id"]]
        and trace["idempotency_key_reserved_before_dispatch"] is True
        and trace["unexpected_mutations"] == 0
        and trace["adapt_requests"] == 0
        and trace["generation_write_requests"] == 0
        and trace["timeline_get_only"] is True,
        "normal_operation_or_idempotency_unproven",
    )
    provider = bundle["core_provider_proof"]
    need(
        all(provider[k] == f[k] for k in ("owner_id", "project_id", "workspace_id"))
        and provider["operation_id"] == op["id"]
        and provider["coverage"] == "complete"
        and provider["revision"] == revision
        and isinstance(provider.get("evidence_sha256"), list)
        and provider["evidence_sha256"]
        and all(hex64(v) for v in provider["evidence_sha256"])
        and all(
            type(provider[k]) is int and provider[k] == 0
            for k in (
                "attempted_calls",
                "completed_calls",
                "inflight_calls",
                "unpaid_receipts",
            )
        ),
        "model_free_unproven",
    )
    need(
        provider["window_start_unix"] <= bundle["before_counts"]["started_unix"]
        and provider["window_end_unix"] >= bundle["after_counts"]["finished_unix"],
        "provider_window_gap",
    )
    need(
        bundle["normal_runtime_proof"]["project_id"] == f["project_id"]
        and bundle["normal_runtime_proof"]["snapshot_id"] == applied["id"]
        and bundle["normal_runtime_proof"]["f5_rendered"] is True
        and bundle["normal_runtime_proof"]["header_bypass"] is False,
        "normal_runtime_unproven",
    )
    return {
        "status": "ROOT_BOUND_CASE1_PROOF_VERIFIED_PARTIAL_T09_4",
        "business_row_count": 0,
        "proof_origin": "root_bound_exports_not_reexecuted",
        "whole_restoration_group_accepted": False,
        "whole67accepted": [],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixture")
    parser.add_argument("--ack")
    parser.add_argument("--revision")
    parser.add_argument("--phase", choices=["before", "after"], default="before")
    parser.add_argument("--context")
    parser.add_argument("--output")
    parser.add_argument("--bundle")
    parser.add_argument("--execute-collect", action="store_true")
    args = parser.parse_args()
    if not args.execute_collect and not args.bundle:
        print(
            json.dumps(
                {
                    "status": "OFFLINE_PLAN_ONLY",
                    "actual_execution": False,
                    "both_databases_required": True,
                    "whole67accepted": [],
                }
            )
        )
        return
    need(args.fixture and args.ack and args.revision, "missing_future_root_inputs")
    f = read_json(args.fixture)
    if args.bundle:
        need(not args.execute_collect, "mixed_modes_forbidden")
        result = verify_bundle(
            f, read_json(args.ack), read_json(args.bundle), args.revision
        )
    else:
        need(args.context and args.output, "missing_collection_inputs")
        result = collect(args, f)
    print(json.dumps(result))


if __name__ == "__main__":
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        print(
            json.dumps(
                {
                    "status": "BLOCKED",
                    "reason": str(exc)
                    if isinstance(exc, Blocked)
                    else type(exc).__name__,
                    "whole67accepted": [],
                }
            )
        )
        raise SystemExit(1) from None
