
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout = '60s';
SET LOCAL lock_timeout = '5s';
SET LOCAL row_security = off;
WITH user_relations AS (
 SELECT n.nspname AS schema_name, c.relname, c.relkind, c.relispartition,
   c.relrowsecurity, pg_catalog.pg_get_userbyid(c.relowner)=current_user AS owner_is_controller,
   (SELECT coalesce(json_agg(json_build_array(a.attname,
      pg_catalog.format_type(a.atttypid,a.atttypmod), a.attnotnull,
      pg_catalog.pg_get_expr(d.adbin,d.adrelid)) ORDER BY a.attnum), '[]')
    FROM pg_catalog.pg_attribute a
    LEFT JOIN pg_catalog.pg_attrdef d ON d.adrelid=c.oid AND d.adnum=a.attnum
    WHERE a.attrelid=c.oid AND a.attnum>0 AND NOT a.attisdropped) AS columns,
   (SELECT coalesce(json_agg(a.attname ORDER BY u.ord), '[]')
    FROM pg_catalog.pg_constraint k
    CROSS JOIN LATERAL unnest(k.conkey) WITH ORDINALITY u(attnum,ord)
    JOIN pg_catalog.pg_attribute a ON a.attrelid=c.oid AND a.attnum=u.attnum
    WHERE k.conrelid=c.oid AND k.contype='p') AS primary_key,
   (SELECT coalesce(json_agg(keys.names ORDER BY keys.names::text), '[]') FROM (
    SELECT json_agg(a.attname ORDER BY u.ord) AS names
    FROM pg_catalog.pg_index i
    CROSS JOIN LATERAL unnest(i.indkey) WITH ORDINALITY u(attnum,ord)
    JOIN pg_catalog.pg_attribute a ON a.attrelid=c.oid AND a.attnum=u.attnum
    WHERE i.indrelid=c.oid AND i.indisunique AND NOT i.indisprimary
     AND i.indexprs IS NULL AND i.indpred IS NULL AND u.ord<=i.indnkeyatts
    GROUP BY i.indexrelid) keys) AS unique_keys,
   CASE WHEN c.relkind = 'r' AND NOT c.relispartition THEN
    ((xpath('/table/row/n/text()', query_to_xml(
      format('SELECT count(*) AS n FROM %I.%I', n.nspname, c.relname),
      false, false, '')))[1]::text)::bigint
   END AS row_count
 FROM pg_catalog.pg_class c
 JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
 WHERE n.nspname NOT IN ('pg_catalog', 'information_schema')
  AND n.nspname <> 'pg_toast'
  AND NOT pg_catalog.pg_is_other_temp_schema(n.oid)
  AND c.relkind IN ('r','p','v','m','f')
), user_sequences AS (
 SELECT n.nspname AS schema_name, c.relname,
   s.seqstart AS start_value,
   ((xpath('/table/row/last_value/text()', query_to_xml(
     format('SELECT last_value, is_called FROM %I.%I', n.nspname, c.relname),
     false, false, '')))[1]::text)::bigint AS last_value,
   ((xpath('/table/row/is_called/text()', query_to_xml(
     format('SELECT last_value, is_called FROM %I.%I', n.nspname, c.relname),
     false, false, '')))[1]::text)::boolean AS is_called
 FROM pg_catalog.pg_class c
 JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
 JOIN pg_catalog.pg_sequence s ON s.seqrelid = c.oid
 WHERE n.nspname NOT IN ('pg_catalog', 'information_schema')
  AND n.nspname <> 'pg_toast'
  AND NOT pg_catalog.pg_is_other_temp_schema(n.oid)
)
SELECT json_build_object(
 'superuser', (SELECT rolsuper FROM pg_catalog.pg_roles WHERE rolname=current_user),
 'row_security_off', current_setting('row_security') = 'off',
 'active_sessions', (SELECT count(*) FROM pg_catalog.pg_stat_activity
   WHERE datid=(SELECT oid FROM pg_catalog.pg_database WHERE datname=current_database())
    AND pid<>pg_backend_pid() AND backend_type='client backend'),
 'large_objects', EXISTS(SELECT FROM pg_catalog.pg_largeobject_metadata),
 'prepared_transactions', EXISTS(SELECT FROM pg_catalog.pg_prepared_xacts
   WHERE database=current_database()),
 'subscriptions', EXISTS(SELECT FROM pg_catalog.pg_subscription),
 'replication_slots', EXISTS(SELECT FROM pg_catalog.pg_replication_slots),
 'database_layout_valid', (SELECT count(*)=3
   AND bool_and(CASE datname WHEN 'postgres' THEN NOT datistemplate AND datallowconn
    WHEN 'template0' THEN datistemplate AND NOT datallowconn
    WHEN 'template1' THEN datistemplate AND datallowconn ELSE false END)
   FROM pg_catalog.pg_database),
 'extensions', coalesce((SELECT json_agg(extname ORDER BY extname)
   FROM pg_catalog.pg_extension), '[]'),
 'relations', coalesce((SELECT json_agg(json_build_object(
   'schema', schema_name, 'name', relname,
   'kind', CASE relkind WHEN 'r' THEN 'table' WHEN 'p' THEN 'partitioned_table'
     WHEN 'v' THEN 'view' WHEN 'm' THEN 'materialized_view' ELSE 'foreign_table' END,
   'partition', relispartition, 'rls', relrowsecurity, 'row_count', row_count,
   'ledger_attestation', CASE WHEN schema_name='public' AND relname='__omnia_migrations'
    THEN json_build_object('shape_attested', owner_is_controller
     AND columns::jsonb = '[
       ["name","text",true,null],
       ["applied_at","timestamp with time zone",true,"now()"]
     ]'::jsonb
     AND primary_key::jsonb = '["name"]'::jsonb AND unique_keys::jsonb = '[]'::jsonb,
     'rows_digest',((xpath('/table/row/digest/text()', query_to_xml(
       $ledger$SELECT encode(sha256(convert_to(coalesce(jsonb_agg(
        jsonb_build_array(name,applied_at) ORDER BY name)::text,'[]'),'UTF8')),'hex') AS digest
        FROM public.__omnia_migrations$ledger$, false, false, '')))[1]::text))
    ELSE NULL END,
   'project_ledger_attestation', CASE
    WHEN schema_name='public' AND relname='__omnia_project_migrations'
    THEN json_build_object('shape_attested', owner_is_controller
     AND columns::jsonb = '[
       ["name","text",true,null], ["sha256","text",true,null],
       ["applied_at","timestamp with time zone",true,"now()"]
     ]'::jsonb
     AND primary_key::jsonb = '["name"]'::jsonb AND unique_keys::jsonb = '[]'::jsonb,
     'rows_valid', ((xpath('/table/row/valid/text()', query_to_xml(
       $journal$SELECT coalesce(bool_and(name ~ '^drizzle/[^/]+[.]sql$'
        AND length(name)<=1024 AND sha256 ~ '^[0-9a-f]{64}$'),true) AS valid
        FROM public.__omnia_project_migrations$journal$, false, false, '')))[1]::text)::boolean,
     'rows_digest', ((xpath('/table/row/digest/text()', query_to_xml(
       $journal$SELECT encode(sha256(convert_to(coalesce(jsonb_agg(
        jsonb_build_array(name,sha256,applied_at)
        ORDER BY name)::text,'[]'),'UTF8')),'hex') AS digest
        FROM public.__omnia_project_migrations$journal$, false, false, '')))[1]::text))
    ELSE NULL END,
   'max_users_attestation', CASE WHEN schema_name='public' AND relname='max_users'
    THEN json_build_object('owner_is_controller',owner_is_controller,
      'columns',columns,'primary_key',primary_key,'unique_keys',unique_keys,
      'rows_digest',((xpath('/table/row/digest/text()', query_to_xml(
       $users$SELECT encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(t)
        ORDER BY max_user_id)::text,'[]'),'UTF8')),'hex') AS digest FROM public.max_users t$users$,
       false, false, '')))[1]::text)) ELSE NULL END)
   ORDER BY schema_name, relname) FROM user_relations), '[]'),
 'sequences', coalesce((SELECT json_agg(json_build_object(
   'schema', schema_name, 'name', relname, 'start_value', start_value,
   'last_value', last_value, 'is_called', is_called)
   ORDER BY schema_name, relname) FROM user_sequences), '[]')
);
COMMIT;
