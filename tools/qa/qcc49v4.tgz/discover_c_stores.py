"""Default NONEXECUTING. Root-only OWN_C label discovery and frozen SELECT witnesses.

No lifecycle/commands/models/SQL writes. Credentials stay inside controller process.
"""

import argparse
import hashlib
import importlib.util
import json
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).parent
PROOF_SHA = "90b72bd10ed08ff3c7c9b2c8d559c177ce5dd045fa86b0246961891d6809b16d"
if (
    hashlib.sha256((HERE / "empty_restore_proof.py").read_bytes()).hexdigest()
    != PROOF_SHA
):
    raise RuntimeError("Frozen proof helper changed")
spec = importlib.util.spec_from_file_location(
    "proof_v3", HERE / "empty_restore_proof.py"
)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
PURPOSE = "OWN_C_DISCOVER_PHYSICAL_STORES"
RELEASE = "49b071162a5017374b96a193c23b9d48e4cf0995"
WORKSPACE_SHA = "43a24989fdbb7fa1d6845eb6d732894de5a0c366630226b57f9372445fe5e24d"
PROJECT_SHA = "9f9147a8ba0b192858dee0aae6650b8b491f504949603883150ebb552d67cda1"
RUN_SHA = "e44f8ac5d1a5cf31a6ef3164fecc3e4fe18e5027ccaa4aff7c989774c04af915"


HOST_BOOTSTRAP = r"""
import json,sys,subprocess,urllib.request,logging
logging.disable(logging.CRITICAL)
rev=subprocess.run(['git','-C','/opt/omnia','rev-parse','HEAD'],capture_output=True,timeout=5)
if rev.returncode!=0 or rev.stdout.decode().strip()!='49b071162a5017374b96a193c23b9d48e4cf0995':
 raise RuntimeError('Host source SHA differs')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs): return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
with opener.open('http://127.0.0.1:8003/health',timeout=5) as response:
 if response.status!=200: raise RuntimeError('Host controller health status differs')
 raw=response.read(65537)
 if len(raw)>65536: raise RuntimeError('Host health oversized')
 health=json.loads(raw)
 if health.get('status')!='ok' or health.get('release_sha')!='49b071162a5017374b96a193c23b9d48e4cf0995':
  raise RuntimeError('Host controller revision differs')
"""

API_LOOKUP = r"""
import json,os,stat,sys,hashlib,logging
logging.disable(logging.CRITICAL)
x=json.load(sys.stdin)
from yleum_api.core.config import get_settings
assert get_settings().omnia_release_sha == x['revision']
fd=os.open('/tmp/qa-owned-c-native1.json',os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd) as f:
 s=os.fstat(f.fileno()); assert stat.S_ISREG(s.st_mode) and s.st_mode&0o077==0 and s.st_size<=65536
 prior=json.load(f)
safe=prior['safe_summary']; raw=prior['exact_scoped_identifiers_private']
assert safe['status']=='ACTUAL_OWN_C_READONLY_DIAGNOSTIC' and safe['revision']==x['revision']
from uuid import UUID
ids={k:str(UUID(raw[k])) for k in ('owner_id','project_id','run_id','workspace_id')}
sha=lambda v:hashlib.sha256(v.encode()).hexdigest()
assert all(sha(ids[k])==x['hashes'][k+'_sha256'] for k in ids)
assert all(safe['scope_id_hashes'][k+'_sha256']==x['hashes'][k+'_sha256'] for k in ('owner_id','project_id','run_id'))
assert safe['workspace']['id_sha256']==x['hashes']['workspace_id_sha256']
print(json.dumps(ids))
"""

STATE_LOOKUP = r"""
import json,sys,logging
from dataclasses import asdict
from uuid import UUID
from pathlib import Path
logging.disable(logging.CRITICAL)
x=json.load(sys.stdin)
from yleum_orchestrator.core.config import get_settings
from yleum_orchestrator.services.cell_state import CellStateStore,_read_plain_json_file
settings=get_settings(); assert settings.omnia_release_sha==x['revision']
store=CellStateStore(settings.cell_state_path); state=store.load(UUID(x['ids']['workspace_id']))
assert state is not None and state.resource_names is not None
assert all(str(getattr(state,k))==x['ids'][k] for k in ('owner_id','project_id','workspace_id'))
assert state.profile_version==settings.cell_profile_version
names=asdict(state.resource_names); names['workspace_id']=str(names['workspace_id'])
root=store.root.parent/'project-machines'
metadata=root/x['ids']['workspace_id']/'docker.json'
m=_read_plain_json_file(metadata) if metadata.is_file() else {}
result={k:str(getattr(state,k)) for k in ('owner_id','project_id','workspace_id')}
result.update(profile_version=state.profile_version,phase=state.phase,bundle_state=state.bundle_state,
 fencing_epoch=state.fencing_epoch,active_generation_run_id=str(state.active_generation_run_id) if state.active_generation_run_id else None,
 active_generation_fencing_epoch=state.active_generation_fencing_epoch,resource_names=names,
 machine_metadata_present=metadata.is_file(),active_database_volume=m.get('active_database_volume'),restore_in_progress=bool(m.get('restore_in_progress')),
 quiesce_state=m.get('quiesce_state'))
print(json.dumps(result))
"""

CONTROLLER_SELECT = r"""
import json,sys,logging,hashlib
from pathlib import Path
from uuid import UUID
from types import SimpleNamespace
logging.disable(logging.CRITICAL)
x=json.load(sys.stdin)
from yleum_orchestrator.core.config import get_settings
from yleum_orchestrator.services.cell_state import CellStateStore,_read_plain_json_file
from yleum_orchestrator.services.restoration_database import admin_sql
from yleum_orchestrator.services.restoration_empty import EMPTY_WITNESS_SQL,TEMPLATE1_WITNESS_SQL
settings=get_settings(); assert settings.omnia_release_sha==x['revision']
store=CellStateStore(settings.cell_state_path); state=store.load(UUID(x['ids']['workspace_id']))
assert state is not None and state.resource_names is not None
assert all(str(getattr(state,k))==x['ids'][k] for k in ('owner_id','project_id','workspace_id'))
assert state.fencing_epoch==x['state']['fencing_epoch'] and state.profile_version==x['state']['profile_version']
assert state.active_generation_run_id is None and state.active_generation_fencing_epoch is None
assert str(state.resource_names.postgres_container)==x['state']['resource_names']['postgres_container']
queries={'catalog-counts.sql':EMPTY_WITNESS_SQL,'template1-counts.sql':TEMPLATE1_WITNESS_SQL}
assert all(hashlib.sha256(v.encode()).hexdigest()==x['query_hashes'][k] for k,v in queries.items())
if x['scope']=='project':
 secret=store.root.parent/'project-machines'/'project-postgres-secrets'/(str(state.workspace_id)+'.json')
else:
 secret=store.root.parent/(store.root.name+'-credentials')/(str(state.workspace_id)+'.json')
# Existing protected file ONLY. This normal secure reader is NOFOLLOW + mode0600;
# unlike load_or_create it never creates directories/files or generates credentials.
payload=_read_plain_json_file(secret)
password=payload.get('postgres_password'); assert isinstance(password,str) and password
import docker
client=docker.DockerClient(base_url=settings.docker_host,timeout=10)
backend=SimpleNamespace(client=client,project_postgres_password=password,
 _project_postgres=lambda:SimpleNamespace(id=x['container_id']))
try:
 out={k:json.loads(admin_sql(backend,v,max_bytes=1024**2,lifetime_seconds=65)) for k,v in queries.items()}
 print(json.dumps(out))
finally:
 client.close()
"""


def scope_binding(data):
    f = data["fixture"]
    h.need(
        data["revision"] == RELEASE
        and f["fixture_label"] == "C"
        and f["owner_role"] == "user",
        "wrong_C_scope",
    )
    hashes = {
        k: f[k]
        for k in (
            "owner_id_sha256",
            "project_id_sha256",
            "run_id_sha256",
            "workspace_id_sha256",
        )
    }
    h.need(all(h.hex64(v) for v in hashes.values()), "missing_actual_scope_hash")
    h.need(
        hashes["project_id_sha256"] == PROJECT_SHA
        and hashes["run_id_sha256"] == RUN_SHA
        and hashes["workspace_id_sha256"] == WORKSPACE_SHA,
        "different_C_project_run",
    )
    h.need(
        h.hex64(data["api_container_id"])
        and data.get("controller_source_sha") == RELEASE,
        "actual_API_and_host_controller_scope_required",
    )
    return dict(
        purpose=PURPOSE,
        revision=RELEASE,
        **hashes,
        api_container_id=data["api_container_id"],
        controller_source_sha=data["controller_source_sha"],
        controller_runtime="host_systemd",
    )


def validate(data):
    binding = scope_binding(data)
    ack = data["read_ack"]
    h.need(
        ack["purpose"] == PURPOSE
        and ack["scope_sha256"] == h.digest(binding)
        and ack["helper_sha256"] == h.file_sha(Path(__file__)),
        "unbound_read_ACK",
    )
    issued = datetime.fromisoformat(ack["issued_at_utc"].replace("Z", "+00:00"))
    h.need(
        issued.tzinfo is not None
        and 0 <= (datetime.now(UTC) - issued).total_seconds() <= 300,
        "stale_read_ACK",
    )
    h.need(
        ack.get("root_readonly_authorized") is True
        and ack.get("exclusive_actor") is True
        and ack.get("inprogress") is False
        and ack.get("model_calls_authorized") is False,
        "read_scope_not_authorized",
    )
    drain = ack["global_drain"]
    h.need(
        drain["evidence_complete"] is True
        and time.time() - 60 <= drain["observed_unix"] <= time.time() + 5
        and len(drain["counts"]) == 4
        and all(type(v) is int and v == 0 for v in drain["counts"].values())
        and h.hex64(drain["evidence_sha256"]),
        "fresh_actual_drain_required",
    )
    return binding


def command(argv, *, payload=None, timeout=15, cwd=None):
    # Never print argv/errors or stderr, which can include private service/log contents.
    result = subprocess.run(
        argv,
        input=json.dumps(payload).encode() if payload is not None else None,
        capture_output=True,
        timeout=timeout,
        cwd=cwd,
    )
    h.need(
        result.returncode == 0 and len(result.stdout) <= 2 * 1024**2,
        "readonly_command_failed",
    )
    return result.stdout


def exec_python(cid, script, payload, timeout=15):
    return json.loads(
        command(
            ["docker", "exec", "-i", cid, "python", "-E", "-c", script],
            payload=payload,
            timeout=timeout,
        )
    )


def host_python(script, payload, timeout=15):
    return json.loads(
        command(
            [
                "/opt/omnia/apps/orchestrator/.venv/bin/python",
                "-E",
                "-c",
                HOST_BOOTSTRAP + script,
            ],
            payload=payload,
            timeout=timeout,
            cwd="/opt/omnia/apps/orchestrator",
        )
    )


def inspect(cid):
    fmt = (
        '{"Id":{{json .Id}},"Name":{{json .Name}},"Running":{{json .State.Running}},'
        '"State":{{json .State}},"Labels":{{json .Config.Labels}},"Mounts":{{json .Mounts}}}'
    )
    return json.loads(command(["docker", "inspect", "--format", fmt, cid]))


def exact_one(ids, kind):
    h.need(len(ids) == 1 and h.hex64(ids[0]), "missing_or_multiple_" + kind)
    return ids[0]


def find(ids, kind, flag):
    argv = ["docker", "ps", "-a", "--no-trunc", "--format", "{{.ID}}"]
    filters = {
        "omnia.managed": "true",
        flag: "true",
        "omnia.resource_kind": kind,
        **{"omnia." + k: ids[k] for k in ("owner_id", "project_id", "workspace_id")},
    }
    for key, value in filters.items():
        argv += ["--filter", "label=" + key + "=" + value]
    candidates = command(argv).decode().splitlines()
    return exact_one(candidates, kind) if candidates else None


def database_binding(actual, ids, state, scope):
    names = state["resource_names"]
    labels = actual["Labels"]
    mounts = [
        m for m in actual["Mounts"] if m["Destination"] == "/var/lib/postgresql/data"
    ]
    h.need(
        len(mounts) == 1 and mounts[0].get("Type") == "volume", "no_exact_data_volume"
    )
    binding = dict(
        container_id=actual["Id"],
        volume_name=mounts[0]["Name"],
        namespace=labels.get("omnia.namespace") if scope == "project" else None,
        fencing_epoch=int(labels["omnia.fencing_epoch"])
        if scope == "project"
        else None,
        profile_version=state["profile_version"],
        resource_kind="project-postgres" if scope == "project" else "postgres",
    )
    fixture = dict(
        **{k: ids[k] for k in ("owner_id", "project_id", "workspace_id")},
        phases={"before": {"databases": {scope: binding}}},
    )
    h.validate_identity(actual, fixture, "before", scope)
    if scope == "trusted_core":
        h.need(
            actual["Name"] == "/" + names["postgres_container"]
            and binding["volume_name"] == names["postgres_volume"],
            "core_state_binding_mismatch",
        )
    else:
        prefix = (
            "omnia-machine-test" if names["namespace"] == "test" else "omnia-machine"
        )
        stem = prefix + "-" + ids["workspace_id"].replace("-", "")
        expected_volume = state["active_database_volume"] or stem + "-app-postgres-data"
        h.need(
            binding["namespace"] == names["namespace"]
            and actual["Name"] == "/" + stem + "-project-postgres"
            and binding["volume_name"] == expected_volume,
            "project_state_binding_mismatch",
        )
    volume = json.loads(
        command(
            [
                "docker",
                "volume",
                "inspect",
                "--format",
                '{"Name":{{json .Name}},"Labels":{{json .Labels}}}',
                binding["volume_name"],
            ]
        )
    )
    expected = {
        "omnia.managed": "true",
        **{"omnia." + k: ids[k] for k in ("owner_id", "project_id", "workspace_id")},
    }
    expected["omnia.resource_kind"] = (
        "project-volume" if scope == "project" else "postgres"
    )
    h.need(
        volume["Name"] == binding["volume_name"]
        and all(volume["Labels"].get(k) == v for k, v in expected.items()),
        "volume_owner_binding_mismatch",
    )
    return binding


def execute(args, data):
    validate(data)
    if args.collect:
        h.need(
            data["read_ack"].get("readonly_sql_authorized") is True,
            "SQL_read_ACK_required",
        )
        h.verified_queries()
    for cid in (data["api_container_id"],):
        service = inspect(cid)
        h.need(
            service["Id"] == cid and service["Running"] is True,
            "canonical_service_not_running",
        )
    hashes = {k: v for k, v in scope_binding(data).items() if k.endswith("_sha256")}
    ids = exec_python(
        data["api_container_id"], API_LOOKUP, dict(revision=RELEASE, hashes=hashes)
    )
    state = host_python(STATE_LOOKUP, dict(revision=RELEASE, ids=ids))
    h.need(
        type(state["fencing_epoch"]) is int
        and state["fencing_epoch"] > 0
        and state["active_generation_run_id"] is None
        and state["active_generation_fencing_epoch"] is None
        and state["profile_version"]
        in {"docker-owner-cell-resources-v1", "docker-owner-cell-resources-v2"}
        and state["restore_in_progress"] is False
        and state["quiesce_state"] not in {"pending", "failed"},
        "controller_binding_unknown_or_active",
    )
    result = dict(
        status="ACTUAL_OWN_C_PHYSICAL_STORE_DISCOVERY",
        actual_execution=True,
        accepted=False,
        revision=RELEASE,
        controller_state=state,
        exact_scoped_identifiers_private=ids,
        scope_id_hashes=hashes,
        started_unix=time.time(),
        databases={},
        whole67accepted=[],
    )
    for scope, kind, flag in [
        ("project", "project-postgres", "omnia.project_machine"),
        ("trusted_core", "postgres", "omnia.project_cell"),
    ]:
        fresh = h.read_json(args.input)
        validate(fresh)
        h.need(scope_binding(fresh) == scope_binding(data), "read_scope_changed")
        if args.collect:
            h.need(
                fresh["read_ack"].get("readonly_sql_authorized") is True,
                "SQL_read_ACK_required",
            )
        cid = find(ids, kind, flag)
        if cid is None:
            result["databases"][scope] = dict(
                present=False,
                empty_witness_valid=False,
                blocking_reason="missing_exact_owned_container",
            )
            continue
        before = inspect(cid)
        binding = database_binding(before, ids, state, scope)
        store = dict(present=True, binding=binding, identity=before)
        if args.collect:
            payload = dict(
                revision=RELEASE,
                ids=ids,
                state=state,
                scope=scope,
                container_id=cid,
                query_hashes=h.QUERY_HASHES,
            )
            witnesses = host_python(CONTROLLER_SELECT, payload, timeout=150)
            store["catalog"] = witnesses["catalog-counts.sql"]
            store["template1"] = witnesses["template1-counts.sql"]
            try:
                h.need(store["template1"] == h.STOCK_TEMPLATE, "template1_not_stock")
                store["classification"] = h.classify_catalog(store["catalog"])
                store["empty_witness_valid"] = True
            except h.Blocked as exc:
                store["empty_witness_valid"] = False
                store["blocking_reason"] = str(exc)
        after = inspect(cid)
        h.need(before == after, "store_identity_changed_during_read")
        result["databases"][scope] = store
    present = [d for d in result["databases"].values() if d.get("present") is True]
    h.need(
        len({d["binding"]["container_id"] for d in present}) == len(present),
        "aliased_physical_stores",
    )
    result["both_stores_present"] = len(present) == 2
    if args.collect:
        result.update(
            phase=args.phase or "diagnostic",
            scope="owned_C_empty_restore",
            scope_ids={k: ids[k] for k in ("owner_id", "project_id", "workspace_id")},
            query_hashes=h.QUERY_HASHES,
            actual_local_collection=True,
        )
    if len(present) != 2:
        result["status"] = "BLOCKED_MISSING_OWNED_STORE_WITH_RETAINED_DIAGNOSTIC"
    final_state = host_python(STATE_LOOKUP, dict(revision=RELEASE, ids=ids))
    h.need(final_state == state, "controller_state_changed_during_read")
    h.need(
        len({d["binding"]["volume_name"] for d in present}) == len(present),
        "aliased_store_volumes",
    )
    result["finished_unix"] = time.time()
    h.private_output(Path(args.output), result)
    return dict(
        status=result["status"],
        actual_execution=True,
        accepted=False,
        stores=sum(d.get("present") is True for d in result["databases"].values()),
        scoped_metadata_sha256=h.digest(result),
        witness_attempted=args.collect,
        both_empty=all(
            d.get("empty_witness_valid") is True for d in result["databases"].values()
        )
        if args.collect
        else None,
        whole67accepted=[],
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input")
    parser.add_argument("--output")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--collect", action="store_true")
    parser.add_argument("--phase", choices=["before", "after"])
    parser.add_argument("--scope-digest", action="store_true")
    args = parser.parse_args()
    if not args.execute and not args.scope_digest:
        print(
            json.dumps(
                dict(
                    status="NONEXECUTING_PREPARATION",
                    actual_execution=False,
                    whole67accepted=[],
                )
            )
        )
        return
    h.need(args.input, "missing_root_input")
    data = h.read_json(args.input)
    if args.scope_digest:
        h.need(not args.execute and not args.collect, "mixed_mode")
        print(json.dumps(dict(scope_sha256=h.digest(scope_binding(data)))))
        return
    h.need(
        args.output and not Path(args.output).exists(), "new_private_output_required"
    )
    print(json.dumps(execute(args, data)))


if __name__ == "__main__":
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        print(
            json.dumps(
                dict(
                    status="BLOCKED",
                    error=str(exc)
                    if isinstance(exc, h.Blocked)
                    else type(exc).__name__,
                    whole67accepted=[],
                )
            )
        )
        raise SystemExit(1) from None
