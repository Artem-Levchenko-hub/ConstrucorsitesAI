"""Default NONEXECUTING; Root-only exact49 C read-only diagnostic launcher."""

import argparse
import hashlib
import importlib.util
import json
import os
import stat
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).parent
OUTPUT_DIR = Path("/tmp/qa-c49-collect")
RELEASE = "49b071162a5017374b96a193c23b9d48e4cf0995"
API_CID = "49c04e498f7e36294d8a637ab2e6b6457eec27d49155f31461c162b73d1ddb79"
HASHES = {
    "discover_c_stores.py": "800d01c6b4b99e752e425c2db8f9a262d0a8b12f885845ea456100146398081a",
    "empty_restore_proof.py": "90b72bd10ed08ff3c7c9b2c8d559c177ce5dd045fa86b0246961891d6809b16d",
    "catalog-counts.sql": "891196b7e232594438f1c55780974a45f36cd75e312afdf76d3fae9bd68288fd",
    "template1-counts.sql": "9cfc3ce8039cd770ef23f649f1d1642112f4151d922ef346dafd2b9598f62ce2",
}
FIXTURE = dict(
    fixture_label="C", owner_role="user",
    owner_id_sha256="f2ef40a428c9e57e4c215d8d6c0a55871d952ca201e6c3edb1be9f50dadbd066",
    project_id_sha256="9f9147a8ba0b192858dee0aae6650b8b491f504949603883150ebb552d67cda1",
    run_id_sha256="e44f8ac5d1a5cf31a6ef3164fecc3e4fe18e5027ccaa4aff7c989774c04af915",
    workspace_id_sha256="43a24989fdbb7fa1d6845eb6d732894de5a0c366630226b57f9372445fe5e24d",
)

# EXACT source49 status function, once, explicitly read-only. No CLI begin/end/check,
# bootstrap, journal/controller command, SQL write, admission change or model call.
DRAIN_SCRIPT = r"""
import asyncio,hashlib,json,logging
from pathlib import Path
logging.disable(logging.CRITICAL)
from yleum_api.core.config import get_settings
from yleum_api.core.db import get_engine,dispose_engine
from yleum_api.services import generation_deployment_drain as module
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker
assert get_settings().omnia_release_sha=='49b071162a5017374b96a193c23b9d48e4cf0995'
assert hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()=='6e84da85df981983aec697337944a3eda8a7767ad6b455fb50f1e012b3277b52'
async def read():
 try:
  async with async_sessionmaker(get_engine(),expire_on_commit=False)() as session:
   await session.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY'))
   await session.execute(text("SET LOCAL statement_timeout = '5s'"))
   result=await module.drain_status(session,bootstrap=False)
   print(json.dumps(result,sort_keys=True))
 finally:
  await dispose_engine()
asyncio.run(read())
"""


class Blocked(RuntimeError):
    pass


def need(condition, code):
    if not condition:
        raise Blocked(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate_json_key")
        result[key] = value
    return result


def validated_counts(raw):
    need(len(raw) <= 65536, "status_oversized")
    data = json.loads(raw, object_pairs_hook=unique_pairs)
    need(
        isinstance(data, dict)
        and set(data) == {"release_sha", "active", "drained", "bootstrap_readonly"}
        and data["release_sha"] is None
        and data["bootstrap_readonly"] is False
        and data["drained"] is False,
        "normal_unfenced_status_required",
    )
    counts = data["active"]
    need(
        isinstance(counts, dict)
        and set(counts) == {"generations", "operations", "leases", "restorations"},
        "actual_counter_names_required",
    )
    need(all(type(v) is int and v == 0 for v in counts.values()), "global_not_idle")
    return counts


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def new_attempt_dir(path):
    # Existing attempt is a STOP, including a failed/unknown prior execution.
    os.mkdir(path, 0o700)
    fsync_directory(path)
    fsync_directory(path.parent)


def write_private(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    fsync_directory(path.parent)


def verify_helpers(directory):
    for name, expected in HASHES.items():
        fd = os.open(directory / name, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            need(stat.S_ISREG(info.st_mode) and info.st_size <= 1024**2, "unsafe_helper")
            need(sha(stream.read()) == expected, "frozen_helper_changed")


def load_discovery(directory):
    verify_helpers(directory)
    spec = importlib.util.spec_from_file_location("frozen_c49_discovery", directory / "discover_c_stores.py")
    discovery = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(discovery)
    return discovery


def make_input(discovery, raw, observed):
    data = dict(
        revision=RELEASE, fixture=FIXTURE.copy(), api_container_id=API_CID,
        controller_source_sha=RELEASE,
    )
    data["read_ack"] = dict(
        purpose=discovery.PURPOSE,
        scope_sha256=discovery.h.digest(discovery.scope_binding(data)),
        helper_sha256=HASHES["discover_c_stores.py"],
        issued_at_utc=datetime.now(UTC).isoformat(),
        root_readonly_authorized=True, exclusive_actor=True,
        inprogress=False, model_calls_authorized=False, readonly_sql_authorized=True,
        global_drain=dict(
            evidence_complete=True, observed_unix=observed,
            evidence_sha256=sha(raw), counts=validated_counts(raw),
        ),
    )
    discovery.validate(data)
    return data


def execute():
    # Invocation by Root asserts the already-authorized exclusive, closed-UI scope.
    # Four-zero service counts alone cannot prove there is no concurrent UI actor.
    need(sys.prefix == "/opt/omnia/apps/orchestrator/.venv", "normal_host_venv_required")
    discovery = load_discovery(HERE)
    new_attempt_dir(OUTPUT_DIR)
    observed = time.time()  # Conservative: freshness starts BEFORE the one query.
    status = subprocess.run(
        ["docker", "exec", "-i", API_CID, "python", "-E", "-c", DRAIN_SCRIPT],
        capture_output=True, timeout=30, check=False,
    )
    write_private(OUTPUT_DIR / "drain-status.raw.json", status.stdout)
    write_private(OUTPUT_DIR / "drain-status.stderr", status.stderr)
    need(status.returncode == 0, "status_read_failed")
    data = make_input(discovery, status.stdout, observed)
    ack_path = OUTPUT_DIR / "read-ack.json"
    write_private(ack_path, json.dumps(data, sort_keys=True).encode())
    discovery.validate(data)
    verify_helpers(HERE)
    outcome = subprocess.run(
        [sys.executable, str(HERE / "discover_c_stores.py"), "--execute", "--collect",
         "--input", str(ack_path), "--output", str(OUTPUT_DIR / "two-store-diagnostic.json")],
        capture_output=True, timeout=360, check=False,
    )
    write_private(OUTPUT_DIR / "collector.stdout.json", outcome.stdout)
    write_private(OUTPUT_DIR / "collector.stderr", outcome.stderr)
    # No private IDs, stdout bodies, stderr, DSNs or untrusted error text are printed.
    print(json.dumps(dict(
        status="COLLECTOR_RETURNED" if outcome.returncode == 0 else "COLLECTOR_BLOCKED",
        actual_execution=True, accepted=False, whole67accepted=[],
        collector_returncode=outcome.returncode,
        drain_sha256=sha(status.stdout), collector_stdout_sha256=sha(outcome.stdout),
        private_artifacts=str(OUTPUT_DIR),
    )))
    return 0 if outcome.returncode == 0 else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps(dict(status="NONEXECUTING_PREPARATION", actual_execution=False, whole67accepted=[])))
        return 0
    try:
        return execute()
    except (Exception, KeyboardInterrupt) as exc:
        print(json.dumps(dict(
            status="BLOCKED", error=str(exc) if isinstance(exc, Blocked) else type(exc).__name__,
            execution_requested=True, accepted=False, whole67accepted=[],
        )))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
