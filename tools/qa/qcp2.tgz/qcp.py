"""Root-only exact C placement SELECT; default never opens files/DB/network."""
import argparse
import asyncio
import hashlib
import json
import logging
import os
import re
import stat
import sys
from datetime import UTC, datetime
from urllib.parse import urlsplit
from uuid import UUID

RELEASE = '49b071162a5017374b96a193c23b9d48e4cf0995'
API_ID = '49c04e498f7e36294d8a637ab2e6b6457eec27d49155f31461c162b73d1ddb79'
PURPOSE = 'OWN_C_READONLY_PLACEMENT'
PRIOR = '/tmp/qa-owned-c-native1.json'
HASHES = {
    'owner_id_sha256': 'f2ef40a428c9e57e4c215d8d6c0a55871d952ca201e6c3edb1be9f50dadbd066',
    'project_id_sha256': '9f9147a8ba0b192858dee0aae6650b8b491f504949603883150ebb552d67cda1',
    'run_id_sha256': 'e44f8ac5d1a5cf31a6ef3164fecc3e4fe18e5027ccaa4aff7c989774c04af915',
    'workspace_id_sha256': '43a24989fdbb7fa1d6845eb6d732894de5a0c366630226b57f9372445fe5e24d',
}
HOST_ALLOWLIST = {'2.153.248.98', '2.153.248.99', '2.153.248.100',
                  'core', 'runtime', 'commerce', 'max-core'}


def sha(value):
    return hashlib.sha256(str(value).encode()).hexdigest()


def scope(data):
    if data.get('revision') != RELEASE or data.get('api_container_id') != API_ID:
        raise ValueError('Exact revision/container scope required')
    if data.get('hashes') != HASHES:
        raise ValueError('Frozen owned C scope differs')
    binding = {'purpose': PURPOSE, 'revision': RELEASE, 'api_container_id': API_ID,
               'hashes': HASHES, 'helper_sha256': sha_bytes(__file__)}
    return sha(json.dumps(binding, sort_keys=True, separators=(',', ':')))


def sha_bytes(path):
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def validate(data):
    digest = scope(data)
    ack = data['read_ack']
    issued = datetime.fromisoformat(ack['issued_at_utc'].replace('Z', '+00:00'))
    if issued.tzinfo is None or not 0 <= (datetime.now(UTC) - issued).total_seconds() <= 300:
        raise ValueError('Fresh root READ ACK required')
    if ack.get('purpose') != PURPOSE or ack.get('scope_sha256') != digest:
        raise ValueError('READ ACK scope differs')
    return digest


def verify_prior(prior):
    safe = prior['safe_summary']
    raw = prior['exact_scoped_identifiers_private']
    if safe.get('status') != 'ACTUAL_OWN_C_READONLY_DIAGNOSTIC' or safe.get('revision') != RELEASE:
        raise ValueError('Actual exact-release native receipt required')
    ids = {k: str(UUID(raw[k])) for k in ('owner_id', 'project_id', 'run_id', 'workspace_id')}
    if any(raw[k] != ids[k] or sha(ids[k]) != HASHES[k + '_sha256'] for k in ids):
        raise ValueError('Private UUID identity differs')
    if safe.get('scope_id_hashes') != HASHES or safe['workspace']['id_sha256'] != HASHES['workspace_id_sha256']:
        raise ValueError('Native scope hashes differ')
    return ids


def read_prior():
    fd = os.open(PRIOR, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd) as f:
        s = os.fstat(f.fileno())
        if not stat.S_ISREG(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o600 or s.st_uid != os.geteuid() or s.st_size > 65536:
            raise ValueError('Protected native receipt required')
        return verify_prior(json.load(f))


def placement_statement(ids):
    from sqlalchemy import select
    from yleum_api.models.project_cell import ProjectCellWorkspace as Workspace
    return select(Workspace.id, Workspace.owner_id, Workspace.project_id, Workspace.orchestrator).where(
        Workspace.id == UUID(ids['workspace_id']), Workspace.owner_id == UUID(ids['owner_id']),
        Workspace.project_id == UUID(ids['project_id']), Workspace.deleted_at.is_(None)).limit(2)


def safe_binding(name, reg, host):
    parts = urlsplit(host.url)
    # Deliberately omit userinfo, path, query, fragment and wildcard suffix.
    hostname = parts.hostname
    allowed = hostname in HOST_ALLOWLIST
    port = parts.port or (443 if parts.scheme == 'https' else 80)
    if parts.scheme not in {'http', 'https'} or not hostname or not 1 <= port <= 65535:
        raise ValueError('Configured host endpoint invalid')
    return {'selected_host': name if name in {'core', 'runtime', 'commerce'} else None,
            'selected_host_sha256': sha(name), 'registry_single': reg.single,
            'registry_resolved_same_name': host.name == name,
            'endpoint_hostname': hostname if allowed else None,
            'endpoint_hostname_sha256': sha(hostname), 'endpoint_port': port if allowed else None}


async def probe(data, ids):
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import async_sessionmaker
    from yleum_api.core.config import get_settings
    from yleum_api.core.db import get_engine, dispose_engine
    from yleum_api.services.orchestrator_hosts import registry
    if get_settings().omnia_release_sha != RELEASE:
        raise ValueError('Actual API revision differs')
    try:
        async with async_sessionmaker(get_engine(), expire_on_commit=False)() as session:
            await session.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY'))
            await session.execute(text("SET LOCAL statement_timeout='5000ms'"))
            row = (await session.execute(placement_statement(ids))).one()
            if any(str(row[i]) != ids[k] for i, k in enumerate(('workspace_id', 'owner_id', 'project_id'))):
                raise ValueError('Actual owned binding differs')
            name = row[3]
            if not isinstance(name, str) or not re.fullmatch(r'[a-z][a-z0-9-]{0,31}', name):
                raise ValueError('Actual selected host name invalid')
            reg = registry()
            host = reg.get(name)  # In-process config lookup only, no host HTTP.
            binding = safe_binding(name, reg, host)
        safe = {'status': 'ACTUAL_OWN_C_READONLY_PLACEMENT', 'captured_utc': datetime.now(UTC).isoformat(),
                'revision': RELEASE, 'api_container_id': API_ID, 'scope_sha256': scope(data),
                'scope_id_hashes': HASHES, 'sql_statements': 3, 'host_network_calls': 0,
                'model_calls': 0, 'accepted_restore': False, **binding}
        private = {'exact_scoped_identifiers_private': ids,
                   'placement_private': {'orchestrator': name, 'configured_url': host.url,
                                         'preview_host_suffix': host.preview_host_suffix}, 'safe_summary': safe}
        return safe, private
    finally:
        await dispose_engine()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--scope-digest', action='store_true')
    parser.add_argument('--raw-output')
    args = parser.parse_args()
    if not args.execute and not args.scope_digest:
        print(json.dumps({'status': 'PREPARED_ONLY_NO_DB_NETWORK', 'purpose': PURPOSE, 'revision': RELEASE}))
        return
    fd = None
    try:
        logging.disable(logging.CRITICAL)
        raw = sys.stdin.read(65537)
        if len(raw) > 65536:
            raise ValueError('Input too large')
        data = json.loads(raw)
        if args.scope_digest and not args.execute:
            print(json.dumps({'scope_sha256': scope(data)}))
            return
        validate(data)
        if not args.raw_output or not re.fullmatch(r'/tmp/qa-owned-c-placement-[A-Za-z0-9_-]{1,50}\.json', args.raw_output):
            raise ValueError('Protected new placement receipt path required')
        ids = read_prior()
        fd = os.open(args.raw_output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        os.fchmod(fd, 0o600)
        validate(data)  # Recheck freshness immediately before DB access.
        safe, private = asyncio.run(asyncio.wait_for(probe(data, ids), timeout=15))
        with os.fdopen(fd, 'w') as f:
            fd = None
            json.dump(private, f)
            f.flush()
            os.fsync(f.fileno())
        print(json.dumps(safe))
    except Exception as exc:
        if fd is not None:
            os.close(fd)
        print(json.dumps({'status': 'OWN_C_PLACEMENT_READ_BLOCKED', 'error_type': type(exc).__name__,
                          'accepted_restore': False}))
        sys.exit(2)


if __name__ == '__main__':
    main()
