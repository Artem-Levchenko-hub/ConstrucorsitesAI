"""Default NONEXECUTING. Root exact49 stage diagnosis; NEVER SQL/collect/lifecycle."""

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).parent
DIRECTORY = Path("/tmp/qa-c49-stage1")
BASE_SHA = "8cc339a68477e5229460e119e8560c4bd43faaadfcf10fc1e7fe5eb56fff246a"
if hashlib.sha256((HERE / "root_collect49.py").read_bytes()).hexdigest() != BASE_SHA:
    raise RuntimeError("Frozen base launcher changed")
spec = importlib.util.spec_from_file_location("readonly_base49", HERE / "root_collect49.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
PHASES = {
    "DRAIN_STATUS": "api_global_idle_status",
    "API_INSPECT": "exact_api_inspect",
    "API_LOOKUP": "api_native_receipt_lookup",
    "HOST_STATE": "host_controller_state_lookup",
}
LIMIT = 2 * 1024**2
INSPECT_FMT = (
    '{"Id":{{json .Id}},"Name":{{json .Name}},"Running":{{json .State.Running}},'
    '"State":{{json .State}},"Labels":{{json .Config.Labels}},"Mounts":{{json .Mounts}}}'
)


class Blocked(RuntimeError):
    pass


class ChildNonzero(RuntimeError):
    pass


class ChildTimeout(RuntimeError):
    pass


def need(condition, code):
    if not condition:
        raise Blocked(code)


def retain_result(directory, phase, result, *, timed_out):
    need(phase in PHASES, "stage_not_allowed")
    raw_out, raw_err = result.stdout or b"", result.stderr or b""
    out, err = raw_out[:LIMIT], raw_err[:LIMIT]
    # Persist failed stderr BEFORE any success/JSON assertion. Nothing is printed.
    base.write_private(directory / (phase + ".stdout"), out)
    base.write_private(directory / (phase + ".stderr"), err)
    metadata = dict(
        stage=phase, kind=PHASES[phase], returncode=result.returncode,
        timed_out=timed_out, stdout_sha256=base.sha(out), stderr_sha256=base.sha(err),
        stdout_bytes=len(raw_out), stderr_bytes=len(raw_err),
        stdout_truncated=len(raw_out) > LIMIT, stderr_truncated=len(raw_err) > LIMIT,
    )
    base.write_private(directory / (phase + ".result.json"), json.dumps(metadata, sort_keys=True).encode())
    return metadata


def allow_command(discovery, phase, argv, cwd):
    expected = {
        "DRAIN_STATUS": (["docker", "exec", "-i", base.API_CID, "python", "-E", "-c", base.DRAIN_SCRIPT], None),
        "API_INSPECT": (["docker", "inspect", "--format", INSPECT_FMT, base.API_CID], None),
        "API_LOOKUP": (["docker", "exec", "-i", base.API_CID, "python", "-E", "-c", discovery.API_LOOKUP], None),
        "HOST_STATE": (["/opt/omnia/apps/orchestrator/.venv/bin/python", "-E", "-c", discovery.HOST_BOOTSTRAP + discovery.STATE_LOOKUP], "/opt/omnia/apps/orchestrator"),
    }
    need(phase in expected and (argv, cwd) == expected[phase], "command_scope_changed")


def recorded_command(discovery, directory, phase, argv, *, payload=None, timeout=15, cwd=None):
    allow_command(discovery, phase, argv, cwd)
    need(timeout == (30 if phase == "DRAIN_STATUS" else 15), "command_timeout_changed")
    start = dict(stage=phase, kind=PHASES[phase], started_unix=time.time())
    base.write_private(directory / (phase + ".start.json"), json.dumps(start, sort_keys=True).encode())
    try:
        child = subprocess.run(
            argv, input=json.dumps(payload).encode() if payload is not None else None,
            capture_output=True, check=False, timeout=timeout, cwd=cwd,
        )
    except subprocess.TimeoutExpired as exc:
        child = subprocess.CompletedProcess([], None, exc.stdout or b"", exc.stderr or b"")
        retain_result(directory, phase, child, timed_out=True)
        raise ChildTimeout from None
    metadata = retain_result(directory, phase, child, timed_out=False)
    if child.returncode != 0:
        raise ChildNonzero
    need(not metadata["stdout_truncated"] and not metadata["stderr_truncated"], "output_oversized")
    return child.stdout


def execute():
    phase = "PREFLIGHT"
    try:
        need(sys.prefix == "/opt/omnia/apps/orchestrator/.venv", "normal_host_venv_required")
        need(base.sha((HERE / "root_collect49.py").read_bytes()) == BASE_SHA, "frozen_launcher_changed")
        discovery = base.load_discovery(HERE)
        base.new_attempt_dir(DIRECTORY)
        phase = "DRAIN_STATUS"
        observed = time.time()
        raw = recorded_command(
            discovery, DIRECTORY, phase,
            ["docker", "exec", "-i", base.API_CID, "python", "-E", "-c", base.DRAIN_SCRIPT],
            timeout=30,
        )
        data = base.make_input(discovery, raw, observed)
        data["read_ack"]["readonly_sql_authorized"] = False  # NO physical SQL scope.
        base.write_private(DIRECTORY / "read-ack.json", json.dumps(data, sort_keys=True).encode())

        def captured(argv, *, payload=None, timeout=15, cwd=None):
            discovery.validate(data)
            return recorded_command(discovery, DIRECTORY, phase, argv, payload=payload, timeout=timeout, cwd=cwd)

        discovery.command = captured  # Only approved inspect/lookup/state scripts below.
        phase = "API_INSPECT"
        actual = discovery.inspect(base.API_CID)
        need(actual["Id"] == base.API_CID and actual["Running"] is True, "exact_api_not_running")
        phase = "API_LOOKUP"
        hashes = {k: v for k, v in discovery.scope_binding(data).items() if k.endswith("_sha256")}
        ids = discovery.exec_python(base.API_CID, discovery.API_LOOKUP, dict(revision=base.RELEASE, hashes=hashes))
        phase = "HOST_STATE"
        state = discovery.host_python(discovery.STATE_LOOKUP, dict(revision=base.RELEASE, ids=ids))
        # Do not infer empty, accepted, healthy runtime or terminal controller state.
        summary = dict(status="THREE_READONLY_STAGES_RETURNED", phase=phase, error_type=None,
                       state_payload_sha256=discovery.h.digest(state), actual_execution=True,
                       accepted=False, whole67accepted=[])
        base.write_private(DIRECTORY / "summary.json", json.dumps(summary, sort_keys=True).encode())
        print(json.dumps(summary))
        return 0
    except (Exception, KeyboardInterrupt) as exc:
        metadata = DIRECTORY / (phase + ".result.json")
        summary = dict(status="BLOCKED", phase=phase, error_type=type(exc).__name__,
                       result_sha256=base.sha(metadata.read_bytes()) if metadata.is_file() else None,
                       accepted=False, whole67accepted=[])
        # No argv/payload/env/private UUID/stdout/stderr/error-message print or export.
        print(json.dumps(summary))
        return 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps(dict(status="NONEXECUTING_PREPARATION", actual_execution=False, whole67accepted=[])))
        return 0
    return execute()


if __name__ == "__main__":
    raise SystemExit(main())
